import os
import cv2
import numpy as np


form  PIL import Image

names = []
paths = []


for users in os.